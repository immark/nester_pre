from distutils.core import setup

setup(
        name = 'nester_pre',
        packages = ['nester_pre'],
        version = '1.4.3',
        author ='Mark Ma',
        author_email = 'maanyng@yahoo.com.tw',
        url = 'https://github.com/immark/nester_pre',
        description = ' A simple printer of nested list',
        license='MIT',
        keywords = ['nester'],
     )
